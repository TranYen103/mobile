<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require "../config.php";

$category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;

$sql = "SELECT products.id, products.name, products.price, products.image,products.description, categories.name AS category 
        FROM products 
        INNER JOIN categories ON products.category_id = categories.id 
        ";

$result = $conn->query($sql);

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

echo json_encode(["status" => "success", "data" => $products]);
?>
