<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

require "../config.php"; 

$sql = "SELECT id, tittle, description, image FROM food_items";
$result = $conn->query($sql);

$foodItems = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $foodItems[] = $row;
    }
}

echo json_encode(["status" => "success", "data" => $foodItems]);
?>
