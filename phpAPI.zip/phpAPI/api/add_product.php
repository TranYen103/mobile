<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST");

require "../config.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['name']) || !isset($data['price']) || !isset($data['category_id']) || !isset($data['image'])) {
    echo json_encode(["status" => "error", "message" => "Thiếu dữ liệu!"]);
    exit;
}

$name = $data['name'];
$price = $data['price'];
$category_id = $data['category_id'];
$image = $data['image'];

$sql = "INSERT INTO products (name, price, image, category_id) VALUES ('$name', $price, '$image', $category_id)";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["status" => "success", "message" => "Thêm sản phẩm thành công"]);
} else {
    echo json_encode(["status" => "error", "message" => "Lỗi: " . $conn->error]);
}
?>
