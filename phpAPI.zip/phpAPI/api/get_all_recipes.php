<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Kết nối đến database
require "../config.php";

// Truy vấn lấy dữ liệu từ bảng recipes có các trường:
// id, name, short_description, full_description, image
$sql = "SELECT id, name, short_description, full_description, image FROM recipes";
$result = $conn->query($sql);

$recipes = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $recipes[] = $row;
    }
}

echo json_encode(["status" => "success", "data" => $recipes]);
?>
