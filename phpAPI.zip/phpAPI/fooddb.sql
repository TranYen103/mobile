-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1:3306
-- Thời gian đã tạo: Th3 18, 2025 lúc 06:06 AM
-- Phiên bản máy phục vụ: 8.2.0
-- Phiên bản PHP: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `fooddb`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Đang đổ dữ liệu cho bảng `categories`
--

INSERT INTO `categories` (`id`, `name`, `image`) VALUES
(1, 'Món chínhhhh', 'https://picsum.photos/300'),
(2, 'Salad', 'https://picsum.photos/300'),
(3, 'Đồ uống', 'https://picsum.photos/300'),
(4, 'Tráng miệng', 'https://picsum.photos/300');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `food_items`
--

DROP TABLE IF EXISTS `food_items`;
CREATE TABLE IF NOT EXISTS `food_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tittle` varchar(255) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Đang đổ dữ liệu cho bảng `food_items`
--

INSERT INTO `food_items` (`id`, `tittle`, `description`, `image`) VALUES
(1, 'Món 1', 'Mô tả cho Món 1', 'recipe-1.jpg'),
(2, 'Món 2', 'Mô tả cho Món 2', 'recipe-2.jpg'),
(3, 'Món 3', 'Mô tả cho Món 3', 'recipe-3.jpg');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `category_id` int DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Đang đổ dữ liệu cho bảng `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`, `category_id`, `description`) VALUES
(1, 'Cơm gà', 50000.00, 'https://picsum.photos/300', 1, 'mô tả test'),
(2, 'Bún bò Huế', 45000.00, 'https://picsum.photos/300', 1, 'mô tả test'),
(8, 'Chè khúc bạch', 25000.00, 'https://picsum.photos/300', 4, NULL);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `recipes`
--

DROP TABLE IF EXISTS `recipes`;
CREATE TABLE IF NOT EXISTS `recipes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `short_description` text,
  `full_description` text,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Đang đổ dữ liệu cho bảng `recipes`
--

INSERT INTO `recipes` (`id`, `name`, `short_description`, `full_description`, `image`) VALUES
(1, 'Công thức Món 1', 'Mô tả ngắn cho Món 1', 'Chi tiết công thức đầy đủ cho Món 1, gồm các bước thực hiện chi tiết và nguyên liệu.', 'recipe-1.jpg'),
(2, 'Công thức Món 2', 'Mô tả ngắn cho Món 2', 'Chi tiết công thức đầy đủ cho Món 2, bao gồm hướng dẫn nấu ăn và mẹo vặt.', 'recipe-2.jpg'),
(3, 'Công thức Món 3', 'Mô tả ngắn cho Món 3', 'Chi tiết công thức đầy đủ cho Món 3, với hướng dẫn chi tiết từng bước.', 'recipe-3.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
